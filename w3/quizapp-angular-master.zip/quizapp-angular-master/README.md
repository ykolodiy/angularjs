This is a very simple quiz app using AngularJS.

Blog link: http://odhyan.com/blog/2014/12/building-a-simple-quiz-app-using-angularjs/
